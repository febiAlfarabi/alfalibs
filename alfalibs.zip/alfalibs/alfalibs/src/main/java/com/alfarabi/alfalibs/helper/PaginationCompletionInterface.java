package com.alfarabi.alfalibs.helper;

/**
 * Created by shayanpourvatan on 4/16/17.
 */

public interface PaginationCompletionInterface {
    void handledDataComplete(boolean isLast);
}