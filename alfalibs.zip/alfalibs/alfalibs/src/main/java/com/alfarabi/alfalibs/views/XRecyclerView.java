package com.alfarabi.alfalibs.views;

import android.content.Context;
import android.support.annotation.Nullable;
import android.support.v7.widget.RecyclerView;
import android.util.AttributeSet;

import com.alfarabi.alfalibs.adapters.recyclerview.VerticalRecyclerAdapter;

/**
 * Created by Alfarabi on 6/19/17.
 */

public class XRecyclerView extends RecyclerView {


    public XRecyclerView(Context context) {
        super(context);
    }

    public XRecyclerView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    public XRecyclerView(Context context, @Nullable AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }

}
