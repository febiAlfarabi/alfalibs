package com.alfarabi.alfalibs.views.interfaze;

import android.view.View;

/**
 * Created by User on 08/07/2017.
 */

public interface EmptyLayoutListener extends View.OnClickListener{
}
