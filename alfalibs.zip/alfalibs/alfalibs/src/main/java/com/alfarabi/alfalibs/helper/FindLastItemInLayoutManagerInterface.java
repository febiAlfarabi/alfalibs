package com.alfarabi.alfalibs.helper;

/**
 * Created by shayanpourvatan on 4/17/17.
 */

public interface FindLastItemInLayoutManagerInterface {
    int findLastVisibleItemPosition();
}