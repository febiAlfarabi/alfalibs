package com.alfarabi.alfalibs.model;

/**
 * Created by Alfarabi on 7/10/17.
 */

public class ExampleModel {

    public String hello ;
}
