package com.alfarabi.alfalibs.helper;

/**
 * Created by shayanpourvatan on 4/16/17.
 */

public interface PaginationInterface {
    void onLoadMore(PaginationCompletionInterface completion);
}