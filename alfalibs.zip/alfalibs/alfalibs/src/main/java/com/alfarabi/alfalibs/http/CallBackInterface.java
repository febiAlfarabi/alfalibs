package com.alfarabi.alfalibs.http;

import retrofit2.Call;
import retrofit2.Callback;

/**
 * Created by Alfarabi on 6/30/17.
 */

public interface CallBackInterface<CR extends ContentResponse> extends Callback<CR>{


}
