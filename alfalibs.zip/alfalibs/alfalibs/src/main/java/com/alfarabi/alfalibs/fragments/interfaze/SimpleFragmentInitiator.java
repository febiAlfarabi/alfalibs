package com.alfarabi.alfalibs.fragments.interfaze;

/**
 * Created by Alfarabi on 6/15/17.
 */

public interface SimpleFragmentInitiator {

    public abstract String getTAG() ;

    public abstract boolean onBackPressed();

    public abstract int contentXmlLayout();


}
