package com.alfarabi.alfalibs.adapters.recyclerview.viewholder;

import android.support.v7.widget.RecyclerView;
import android.view.View;

/**
 * Created by Alfarabi on 7/19/17.
 */

public class LoadingViewHolder extends RecyclerView.ViewHolder {


    public LoadingViewHolder(View itemView) {
        super(itemView);
    }
}
