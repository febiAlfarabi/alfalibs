package com.alfarabi.alfalibs.tools;

/**
 * Created by Alfarabi on 6/19/17.
 */

public class Demo {

    public static final int LENGTH_DEMO_1 = 8;
    public static final int LENGTH_DEMO_2 = 17;
    public static final int LENGTH_DEMO_3 = 9;
    public static final int LENGTH_DEMO_4 = 10;

}
