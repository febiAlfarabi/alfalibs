package com.alfarabi.alfalibs.http;

import java.util.HashMap;

/**
 * Created by Alfarabi on 6/30/17.
 */

public class ContentResponse<E> extends HashMap {

}
