package com.alfarabi.alfalibs.http;

/**
 * Created by User on 02/07/2017.
 */

public class Initial {

    public static String DOMAIN_MOCK = "https://www.fork.com";
    public static String API_VERSION = "api/v1";

    public static final String getApi(){
        return "api/v1";
    }

    static {
        getApi();
    }

}
