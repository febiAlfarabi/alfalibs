package com.alfarabi.alfalibs.tools;

/**
 * Created by alfarabi on 3/13/18.
 */

public class GatotKaca {
}
