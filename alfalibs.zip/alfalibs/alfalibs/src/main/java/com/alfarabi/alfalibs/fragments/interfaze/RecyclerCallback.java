package com.alfarabi.alfalibs.fragments.interfaze;

/**
 * Created by Alfarabi on 6/15/17.
 */

public interface RecyclerCallback<O> {
    public O getObject();

}
