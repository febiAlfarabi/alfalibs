package com.alfarabi.alfalibs.activity;

/**
 * Created by Alfarabi on 6/15/17.
 */

public interface SimpleActivityInitiator {

    public abstract String getTAG() ;

    public abstract int contentXmlLayout();
}
