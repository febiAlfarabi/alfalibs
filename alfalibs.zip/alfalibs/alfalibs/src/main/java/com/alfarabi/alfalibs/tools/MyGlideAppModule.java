package com.alfarabi.alfalibs.tools;

import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.module.AppGlideModule;

/**
 * Created by Alfarabi on 6/23/17.
 */

@GlideModule
public class MyGlideAppModule extends AppGlideModule{}
