package com.alfarabi.alfalibs.helper.model;

/**
 * Created by Alfarabi on 6/22/17.
 */

public interface SearchableInterface {

    public boolean isSearchable();
    public String canSearchByField() ;

}
