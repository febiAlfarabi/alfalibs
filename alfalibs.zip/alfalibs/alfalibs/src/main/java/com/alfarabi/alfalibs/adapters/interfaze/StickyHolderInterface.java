package com.alfarabi.alfalibs.adapters.interfaze;

/**
 * Created by alfarabi on 1/15/18.
 */

public interface StickyHolderInterface {


    public boolean needHeader();
}
