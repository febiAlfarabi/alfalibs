package com.alfarabi.alfalibsapps;

import com.alfarabi.alfalibs.http.ContentResponse;

/**
 * Created by Alfarabi on 6/30/17.
 */

public class GithubResponse extends ContentResponse<GithubResponse> {

}
