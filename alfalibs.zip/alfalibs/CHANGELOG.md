Version 1.0.0 *(2017-06-22)*
----------------------------
* Initial Release
* Ready to pull as your android project dependency v1.0.0
